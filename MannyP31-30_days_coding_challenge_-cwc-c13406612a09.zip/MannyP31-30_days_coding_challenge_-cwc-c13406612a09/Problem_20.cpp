#include <unistd.h> 
int main() 
{ 
  write(1, "Hello I am Manisha", 12); 
  return 0; 
} 